#include "main.h"

/**
 * add - Check Main
 * @a: An integer a
 * @b: An integer b
 * Description: Function that adds two integers and returns the result
 * Return: Result to add a and b
 */
int add(int a, int b)
{
	return (a + b);
}
