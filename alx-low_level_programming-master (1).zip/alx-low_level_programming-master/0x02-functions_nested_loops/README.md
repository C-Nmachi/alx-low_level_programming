files on nested loops
