done with if else statement
